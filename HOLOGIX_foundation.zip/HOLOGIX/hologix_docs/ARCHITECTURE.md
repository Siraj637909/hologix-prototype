# Hologix initial architecture
