import secrets
def generate_api_key(): return "hgx_sk_"+secrets.token_hex(24)
